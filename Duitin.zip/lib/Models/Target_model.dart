import 'dart:convert';

// Fungsi untuk decode JSON menjadi List<TargetModel>
List<TargetModel> targetModelFromJson(String str) => List<TargetModel>.from(
    json.decode(str).map((x) => TargetModel.fromJson(x)));

// Fungsi untuk encode List<TargetModel> menjadi JSON
String targetModelToJson(List<TargetModel> data) =>
    json.encode(List<dynamic>.from(data.map((x) => x.toJson())));

class TargetModel {
  TargetModel({
    this.id,
    this.iduser,
    this.namaTarget,
    this.jumlahTarget,
    this.jumlahTerkumpul,
    this.tenggat,
  });

  String? id; // ID unik target tabungan
  String? iduser; // ID user pemilik target
  String? namaTarget; // Nama/deskripsi target tabungan
  double? jumlahTarget; // Jumlah target tabungan
  double? jumlahTerkumpul; // Jumlah yang sudah terkumpul
  DateTime? tenggat; // Tenggat waktu target

  // Factory untuk parse dari JSON ke TargetModel
  factory TargetModel.fromJson(Map<String, dynamic> json) => TargetModel(
        id: json["id"] ?? '',
        iduser: json["iduser"] ?? '',
        namaTarget: json["nama_target"] ?? '',
        jumlahTarget: (json["jumlah_target"] != null)
            ? double.tryParse(json["jumlah_target"].toString()) ?? 0.0
            : 0.0,
        jumlahTerkumpul: (json["jumlah_terkumpul"] != null)
            ? double.tryParse(json["jumlah_terkumpul"].toString()) ?? 0.0
            : 0.0,
        tenggat:
            json["tenggat"] != null ? DateTime.parse(json["tenggat"]) : null,
      );

  // Konversi dari TargetModel ke JSON
  Map<String, dynamic> toJson() => {
        "id": id,
        "iduser": iduser,
        "nama_target": namaTarget,
        "jumlah_target": jumlahTarget,
        "jumlah_terkumpul": jumlahTerkumpul,
        "tenggat": tenggat?.toIso8601String(),
      };
}
