import 'dart:convert';

List<TabunganModel> tabunganModelFromJson(String str) =>
    List<TabunganModel>.from(
        json.decode(str).map((x) => TabunganModel.fromJson(x)));

String tabunganModelToJson(List<TabunganModel> data) =>
    json.encode(List<dynamic>.from(data.map((x) => x.toJson())));

class TabunganModel {
  TabunganModel({
    this.id,
    this.type,
    this.amount,
    this.iduser, 
    this.date,
  });

  String? id;
  String? type;
  double? amount;
  String? iduser; 
  DateTime? date;

  factory TabunganModel.fromJson(Map<String, dynamic> json) => TabunganModel(
        id: json["id"],
        type: json["type"],
        amount: json["amount"]?.toDouble(),
        iduser: json["iduser"], 
        date: DateTime.parse(json["date"]),
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "type": type,
        "amount": amount,
        "iduser": iduser,
        "date": date?.toIso8601String(),
      };
}
