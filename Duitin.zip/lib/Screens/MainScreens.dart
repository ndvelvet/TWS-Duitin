import 'dart:convert';

import 'package:vigenesia/Screens/Beranda.dart';
import 'package:vigenesia/Screens/Tabungan.dart';
import 'package:vigenesia/Screens/Target_Tabungan.dart';

import '/../Models/Motivasi_Model.dart';
import '/../Screens/EditPage.dart';
import 'package:flutter/material.dart';
import 'package:dio/dio.dart';
import 'package:flutter_form_builder/flutter_form_builder.dart';
import 'Login.dart';
import 'package:another_flushbar/flushbar.dart';

class MainScreens extends StatefulWidget {
  final String? nama;
  final String? iduser;
  const MainScreens({Key? key, this.nama, this.iduser}) : super(key: key);

  @override
  _MainScreensState createState() => _MainScreensState();
}

class _MainScreensState extends State<MainScreens> {
  String baseurl =
      "http://localhost/vigenesia"; // ganti dengan ip address kamu / tempat kamu menyimpan backend
  String? id;
  var dio = Dio();

  Future<dynamic> postMotivasi(String isi_motivasi, String iduser) async {
    dynamic isi = {
      "isi_motivasi": isi_motivasi,
      "iduser": iduser,
    };

    try {
      print("Request Body: ${jsonEncode(isi)}");

      var response = await dio.post("$baseurl/api/dev/POSTmotivasi",
          data: jsonEncode(isi),
          options: Options(headers: {"Content-Type": "application/json"}));

      print("Respon -> ${response.data} ");
      return response.data;
    } catch (e) {
      print("Error di -> $e");
    }
  }

  List<MotivasiModel> listproduk = [];

  Future<List<MotivasiModel>> getData() async {
    var response = await dio.get('$baseurl/api/Get_motivasi/');

    print(" ${response.data}");
    if (response.statusCode == 200) {
      var getUsersData = response.data as List;
      var listUsers =
          getUsersData.map((i) => MotivasiModel.fromJson(i)).toList();
      return listUsers;
    } else {
      throw Exception('Failed to load');
    }
  }

  Future<dynamic> deletePost(String id) async {
    dynamic data = {
      "id": id,
    };
    var response = await dio.delete('$baseurl/api/dev/DELETEmotivasi',
        data: data,
        options: Options(
            contentType: Headers.formUrlEncodedContentType,
            headers: {"Content-type": "application/json"}));

    print(" ${response.data}");

    //var resbody = /*jsonDecode*/(response.data);
    var resbody = (response.data);
    return resbody;
  }

  Future<void> _getData() async {
    setState(() {
      getData();
    });

    try {
      var response = await dio.delete(
        '$baseurl/api/dev/DELETEmotivasi',
        data: {"id": id}, // Pastikan data sesuai dengan format API
        options: Options(
          contentType: Headers.formUrlEncodedContentType,
          headers: {"Content-type": "application/json"},
        ),
      );

      // Tidak perlu memanggil jsonDecode jika response.data sudah berupa Map
      if (response.statusCode == 200) {
        print("Response Data: ${response.data}");
        return response.data; // Langsung kembalikan response.data
      } else {
        return null; // Tanggapi status gagal dengan null
      }
    } catch (e) {
      print("Error di deletePost -> $e");
      return null;
    }
  }

  TextEditingController isiController = TextEditingController();
  TextEditingController idController = TextEditingController();

  @override
  void initState() {
    super.initState();
    getData();
    _getData();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Motivasi"),
        leading: Builder(
          builder: (BuildContext context) {
            return IconButton(
              icon: Icon(Icons.menu),
              onPressed: () {
                Scaffold.of(context).openDrawer(); // Membuka Drawer saat diklik
              },
            );
          },
        ),
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: <Widget>[
            DrawerHeader(
              decoration: BoxDecoration(
                color: Colors.blue,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  CircleAvatar(
                    radius: 30,
                    backgroundColor: Colors.white,
                    child: Icon(
                      Icons.person,
                      size: 40,
                      color: Colors.blue,
                    ),
                  ),
                  SizedBox(height: 10),
                  Text(
                    'Halo, ${widget.nama ?? 'Pengguna'}',
                    style: TextStyle(color: Colors.white, fontSize: 16),
                  ),
                  Text(
                    widget.iduser ?? '',
                    style: TextStyle(color: Colors.white70, fontSize: 14),
                  ),
                ],
              ),
            ),
            ListTile(
              leading: Icon(Icons.home),
              title: Text('Beranda'),
              onTap: () {
                Navigator.pop(context);
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => Beranda(
                              nama: widget.nama,
                              iduser: widget.iduser,
                            )));
              },
            ),
            ListTile(
              leading: Icon(Icons.star),
              title: Text('Motivasi'),
              onTap: () {
                Navigator.pop(context);
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => MainScreens(
                              nama: widget.nama,
                              iduser: widget.iduser,
                            )));
              },
            ),
            ListTile(
              leading: Icon(Icons.account_balance_wallet),
              title: Text('Tabungan'),
              onTap: () {
                Navigator.pop(context);
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => Tabungan(
                              nama: widget.nama,
                              iduser: widget.iduser,
                            )));
              },
            ),
            ListTile(
              leading: Icon(Icons.track_changes),
              title: Text('Target Tabungan'),
              onTap: () {
                Navigator.pop(context);
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => TargetTabungan(
                            //nama: widget.nama,
                            //iduser: widget.iduser,
                            )));
              },
            ),
            ListTile(
              leading: Icon(Icons.logout),
              title: Text('Keluar'),
              onTap: () {
                Navigator.pop(context); // Tutup Drawer
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => Login()),
                );
              },
            ),
          ],
        ),
      ),
      body: SingleChildScrollView(
        // <-- Berfungsi Untuk  Bisa Scroll
        child: SafeArea(
          // < -- Biar Gak Keluar Area Screen HP
          child: Container(
            child: Padding(
              padding: const EdgeInsets.only(left: 30.0, right: 30.0),
              child: Column(
                  mainAxisAlignment: MainAxisAlignment
                      .center, // <-- Berfungsi untuk  atur nilai X jadi tengah
                  children: [
                    SizedBox(
                      height: 40,
                    ),

                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          "Hallo ${widget.nama}",
                          style: TextStyle(
                              fontSize: 22, fontWeight: FontWeight.w500),
                        ),
                        /*TextButton(
                            child: Icon(Icons.logout),
                            onPressed: () {
                              Navigator.pop(context);
                              Navigator.push(
                                  context,
                                  new MaterialPageRoute(
                                      builder: (BuildContext context) =>
                                          new Login()));
                            })
                            */
                      ],
                    ),

                    SizedBox(height: 20), // <-- Kasih Jarak Tinggi : 50px
                    FormBuilderTextField(
                      controller: isiController,
                      name: "isi_motivasi",
                      decoration: InputDecoration(
                        border: OutlineInputBorder(),
                        contentPadding: EdgeInsets.only(left: 10),
                      ),
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    Container(
                      width: MediaQuery.of(context).size.width,
                      child: ElevatedButton(
                          onPressed: () async {
                            await postMotivasi(isiController.text.toString(),
                                    widget.iduser!)
                                .then((value) => {
                                      if (value != null)
                                        {
                                          Flushbar(
                                            message: "Berhasil Submit",
                                            duration: Duration(seconds: 2),
                                            backgroundColor: Colors.greenAccent,
                                            flushbarPosition:
                                                FlushbarPosition.TOP,
                                          ).show(context)
                                        }
                                    });

                            _getData();
                            print("Sukses");
                          },
                          child: Text("Submit")),
                    ),

                    SizedBox(
                      height: 40,
                    ),
                    TextButton(
                      child: Icon(Icons.refresh),
                      onPressed: () {
                        _getData();
                      },
                    ),
                    FutureBuilder(
                      future: getData(),
                      builder: (BuildContext context,
                          AsyncSnapshot<List<MotivasiModel>> snapshot) {
                        if (snapshot.hasData) {
                          return ListView.builder(
                            shrinkWrap: true,
                            physics:
                                NeverScrollableScrollPhysics(), // Mencegah konflik scroll
                            itemCount: snapshot.data!.length,
                            itemBuilder: (context, index) {
                              final item = snapshot.data![index];
                              return Card(
                                margin: EdgeInsets.symmetric(
                                    vertical: 8), // Jarak antar item
                                child: Padding(
                                  padding: EdgeInsets.all(
                                      12), // Padding di dalam item
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Expanded(
                                        child: Text(
                                          item.isi_motivasi.toString(),
                                          style: TextStyle(fontSize: 16),
                                        ),
                                      ),
                                      if (item.iduser == widget.iduser)
                                        Row(
                                          children: [
                                            IconButton(
                                              icon: Icon(Icons.edit),
                                              onPressed: () {
                                                Navigator.push(
                                                  context,
                                                  MaterialPageRoute(
                                                    builder: (context) =>
                                                        EditPage(
                                                      id: item.id,
                                                      isi_motivasi:
                                                          item.isi_motivasi,
                                                    ),
                                                  ),
                                                );
                                              },
                                            ),
                                            IconButton(
                                              icon: Icon(Icons.delete),
                                              onPressed: () {
                                                deletePost(item.id.toString())
                                                    .then((value) {
                                                  if (value != null) {
                                                    Flushbar(
                                                      message:
                                                          "Berhasil Delete",
                                                      duration:
                                                          Duration(seconds: 2),
                                                      backgroundColor:
                                                          Colors.redAccent,
                                                      flushbarPosition:
                                                          FlushbarPosition.TOP,
                                                    ).show(context);
                                                    _getData(); // Refresh data setelah delete
                                                  }
                                                });
                                              },
                                            ),
                                          ],
                                        ),
                                    ],
                                  ),
                                ),
                              );
                            },
                          );
                        } else if (snapshot.hasData && snapshot.data!.isEmpty) {
                          return Center(child: Text("Tidak ada motivasi."));
                        } else {
                          return Center(child: CircularProgressIndicator());
                        }
                      },
                    )

                    // FutureBuilder(
                    //     future: getData(),
                    //     builder: (BuildContext context,AsyncSnapshot<List<MotivasiModel>> snapshot) {
                    //       if (snapshot.hasData) {
                    //         return Column(
                    //           children: [
                    //             for (var item in snapshot.data!)
                    //               Container(
                    //                 width: MediaQuery.of(context).size.width,
                    //                 child: ListView(
                    //                   shrinkWrap: true,
                    //                   children: [
                    //                     Expanded(
                    //                       child: Row(
                    //                         mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    //                         children: [
                    //                           Text(item.isi_motivasi.toString()),
                    //                           Row(
                    //                             children: [
                    //                             if(item.iduser == widget.iduser)
                    //                               TextButton(child: Icon(Icons.settings),
                    //                                 onPressed: () {
                    //                                   String id;
                    //                                   String isi_motivasi;
                    //                                   Navigator.push(
                    //                                       context,
                    //                                       MaterialPageRoute(
                    //                                         builder: (BuildContext
                    //                                                 context) =>
                    //                                             EditPage(
                    //                                                 id: item.id,
                    //                                                 isi_motivasi:
                    //                                                     item.isi_motivasi),
                    //                                       ));
                    //                                 },
                    //                               ),
                    //                               if(item.iduser == widget.iduser)
                    //                                 TextButton(
                    //                                   child: Icon(Icons.delete),

                    //                                   onPressed: () {
                    //                                     deletePost(item.id.toString())
                    //                                       .then((value) => {
                    //                                             if (value != null)
                    //                                               {
                    //                                                 Flushbar(
                    //                                                   message: "Berhasil Delete",
                    //                                                   duration: Duration(seconds:2),
                    //                                                   backgroundColor:Colors.redAccent,
                    //                                                   flushbarPosition: FlushbarPosition.TOP,
                    //                                                 ).show(context),
                    //                                               }
                    //                                           });
                    //                                     _getData();
                    //                                   },
                    //                                 )

                    //                             ],
                    //                           ),
                    //                         ],
                    //                       ),
                    //                     ),
                    //                   ],
                    //                 ),
                    //               ),
                    //           ],
                    //         );
                    //       } else if (snapshot.hasData &&
                    //           snapshot.data!.isEmpty) {
                    //         return Text("No Data");
                    //       } else {
                    //         return CircularProgressIndicator();
                    //       }
                    //     })
                  ]),
            ),
          ),
        ),
      ),
    );
  }
}
