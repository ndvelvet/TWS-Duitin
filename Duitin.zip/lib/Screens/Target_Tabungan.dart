import 'package:flutter/material.dart';
import 'package:dio/dio.dart';
import 'package:intl/intl.dart';
import 'package:vigenesia/Screens/Beranda.dart';
import 'package:vigenesia/Screens/MainScreens.dart';
import 'package:vigenesia/Screens/Tabungan.dart';
import 'package:vigenesia/Screens/Login.dart';
import 'package:vigenesia/Models/Target_model.dart';

class TargetTabungan extends StatefulWidget {
  final String? nama;
  final String? iduser; // ID pengguna untuk API

  const TargetTabungan({Key? key, this.nama, this.iduser}) : super(key: key);

  @override
  State<TargetTabungan> createState() => _TargetTabunganState();
}

class _TargetTabunganState extends State<TargetTabungan> {
  final TextEditingController _targetController = TextEditingController();
  final TextEditingController _namaTargetController = TextEditingController();
  double targetAmount = 0.0;
  String targetName = '';
  bool isLoading = true;

  Dio dio = Dio();

  @override
  void initState() {
    super.initState();
    fetchTargetData();
  }

  // Fungsi untuk mengambil target tabungan dari backend
  Future<void> fetchTargetData() async {
    try {
      final response = await dio.get(
          'http://[::1]/vigenesia/api/Get_target_tabungan?iduser=${widget.iduser}');
      if (response.statusCode == 200) {
        var data = response.data['data'];
        setState(() {
          targetAmount = double.tryParse(data['totalTarget'] ?? '0') ?? 0.0;
          targetName = data['nama_target'] ?? '';
        });
      } else {
        throw Exception('Gagal memuat data');
      }
    } catch (e) {
      print('Error fetching target data: $e');
    } finally {
      setState(() {
        isLoading = false;
      });
    }
  }

  // Fungsi untuk menyimpan target tabungan baru
  Future<void> saveTarget() async {
    try {
      final response = await dio.post(
        'http://[::1]/vigenesia/api/Post_target_tabungan?iduser=${widget.iduser}',
        data: {
          'iduser': widget.iduser,
          'nama_target': _namaTargetController.text,
          'jumlah_target': _targetController.text,
          'jumlah_terkumpul': 0,
          'tenggat': '2025-12-31',
        },
      );

      print('Response: ${response.data}');

      if (response.statusCode == 201) {
        // Refresh data setelah berhasil menyimpan
        await fetchTargetData();
        // Reset form input
        _namaTargetController.clear();
        _targetController.clear();
        // Tampilkan pesan sukses
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              'Target berhasil disimpan!',
              style: TextStyle(color: Colors.white),
            ),
            backgroundColor: Colors.green,
          ),
        );
      } else {
        throw Exception('Gagal menyimpan target tabungan');
      }
    } catch (e) {
      print('Error saving target data: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Gagal menyimpan target tabungan'),
        ),
      );
    }
  }

  // Format angka dengan pemisah ribuan
  String _formatNumber(double value) {
    final format = NumberFormat('#,###', 'id_ID');
    return format.format(value);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Target Tabungan'),
        leading: Builder(
          builder: (BuildContext context) {
            return IconButton(
              icon: Icon(Icons.menu),
              onPressed: () {
                Scaffold.of(context).openDrawer(); // Membuka Drawer saat diklik
              },
            );
          },
        ),
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: <Widget>[
            DrawerHeader(
              decoration: BoxDecoration(color: Colors.blue),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  CircleAvatar(
                    radius: 30,
                    backgroundColor: Colors.white,
                    child: Icon(Icons.person, size: 40, color: Colors.blue),
                  ),
                  SizedBox(height: 10),
                  Text(
                    'Halo, ${widget.nama ?? 'Pengguna'}',
                    style: TextStyle(color: Colors.white, fontSize: 16),
                  ),
                  Text(
                    widget.iduser ?? '',
                    style: TextStyle(color: Colors.white70, fontSize: 14),
                  ),
                ],
              ),
            ),
            ListTile(
              leading: Icon(Icons.home),
              title: Text('Beranda'),
              onTap: () {
                Navigator.pop(context);
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => Beranda(
                            nama: widget.nama,
                            iduser: widget.iduser,
                          )),
                );
              },
            ),
            ListTile(
              leading: Icon(Icons.star),
              title: Text('Motivasi'),
              onTap: () {
                Navigator.pop(context);
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => MainScreens(
                            nama: widget.nama,
                            iduser: widget.iduser,
                          )),
                );
              },
            ),
            ListTile(
              leading: Icon(Icons.account_balance_wallet),
              title: Text('Tabungan'),
              onTap: () {
                Navigator.pop(context);
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => Tabungan(
                            nama: widget.nama,
                            iduser: widget.iduser,
                          )),
                );
              },
            ),
            ListTile(
              leading: Icon(Icons.track_changes),
              title: Text('Target Tabungan'),
              onTap: () {
                Navigator.pop(context);
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => TargetTabungan(
                            nama: widget.nama,
                            iduser: widget.iduser,
                          )),
                );
              },
            ),
            ListTile(
              leading: Icon(Icons.logout),
              title: Text('Keluar'),
              onTap: () {
                Navigator.pop(context);
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => Login()),
                );
              },
            ),
          ],
        ),
      ),
      body: isLoading
          ? Center(child: CircularProgressIndicator())
          : Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Target Tabungan Anda:',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 10),
                  Card(
                    color: Colors.teal[50],
                    child: ListTile(
                      leading: Icon(Icons.track_changes, color: Colors.teal),
                      title: Text(
                        'Rp ${_formatNumber(targetAmount)}',
                        style: TextStyle(
                          fontSize: 18,
                          color: Colors.teal[900],
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      subtitle: Text(
                        targetName.isNotEmpty
                            ? 'Nama Target: $targetName'
                            : 'Belum ada target',
                        style: TextStyle(color: Colors.teal[700]),
                      ),
                    ),
                  ),
                  Text(
                    'Atur Target Baru:',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 10),
                  TextField(
                    controller: _namaTargetController,
                    decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      labelText: 'Masukkan Nama Target',
                      hintText: 'Contoh: Liburan ke Bandung',
                    ),
                  ),
                  SizedBox(height: 10),
                  TextField(
                    controller: _targetController,
                    keyboardType: TextInputType.number,
                    decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      labelText: 'Masukkan Target Tabungan',
                      hintText: 'Contoh: 5000000',
                    ),
                  ),
                  SizedBox(height: 20),
                  ElevatedButton(
                    onPressed: () async {
                      if (_targetController.text.isEmpty ||
                          _namaTargetController.text.isEmpty) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: Text(
                              'Nama target dan jumlah target tidak boleh kosong',
                              style: TextStyle(color: Colors.white),
                            ),
                            backgroundColor: Colors.red,
                          ),
                        );
                        return;
                      }

                      // Simpan data target
                      await saveTarget();

                      // tampilkan pesan sukses
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Text(
                            'Target berhasil disimpan!',
                            style: TextStyle(color: Colors.white),
                          ),
                          backgroundColor: Colors.green,
                        ),
                      );

                      // Memuat ulang data target tabungan
                      // await fetchTargetData();
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.teal,
                      padding:
                          EdgeInsets.symmetric(horizontal: 50, vertical: 15),
                    ),
                    child: Text(
                      'Simpan Target',
                      style: TextStyle(fontSize: 16, color: Colors.white),
                    ),
                  ),
                ],
              ),
            ),
    );
  }
}
