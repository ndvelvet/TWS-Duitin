import 'package:flutter/material.dart';
import 'package:dio/dio.dart';
import 'package:intl/intl.dart'; // Untuk format tanggal

class RiwayatTransaksi extends StatefulWidget {
  final String? iduser;

  RiwayatTransaksi({Key? key, this.iduser}) : super(key: key);

  @override
  _RiwayatTransaksiState createState() => _RiwayatTransaksiState();
}

class _RiwayatTransaksiState extends State<RiwayatTransaksi> {
  bool isLoading = true;
  List<dynamic> transactions = [];
  Dio dio = Dio();

  @override
  void initState() {
    super.initState();
    fetchTransactionHistory();
  }

  // Fungsi untuk mengambil data riwayat transaksi dari API backend menggunakan Dio
  Future<void> fetchTransactionHistory() async {
    try {
      final response = await dio.get(
          'http://localhost/vigenesia/api/TransactionHistory?iduser=${widget.iduser}');

      if (response.statusCode == 200) {
        var data = response.data['data']; // Assume response has 'data' field

        if (data != null) {
          setState(() {
            transactions = data.map((transaction) {
              // Parse amount from String to double
              return {
                ...transaction,
                'amount': double.tryParse(transaction['amount']) ?? 0.0,
              };
            }).toList();
            isLoading = false;
          });
        } else {
          setState(() {
            transactions = [];
            isLoading = false;
          });
        }
      } else {
        throw Exception('Failed to load transaction history');
      }
    } catch (e) {
      print('Error fetching transaction history: $e');
      setState(() {
        isLoading = false;
      });
    }
  }

  // Fungsi untuk format tanggal
  String _formatDate(String date) {
    try {
      DateTime parsedDate = DateTime.parse(date);
      return DateFormat('dd MMM yyyy').format(parsedDate);
    } catch (e) {
      return date;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Riwayat Transaksi'),
      ),
      body: isLoading
          ? Center(child: CircularProgressIndicator())
          : transactions.isEmpty
              ? Center(child: Text('Tidak ada transaksi'))
              : ListView.builder(
                  itemCount: transactions.length,
                  itemBuilder: (context, index) {
                    var transaction = transactions[index];
                    return Card(
                      margin: EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                      child: ListTile(
                        leading: Icon(
                          transaction['type'] == 'income'
                              ? Icons.arrow_downward
                              : Icons.arrow_upward,
                          color: transaction['type'] == 'income'
                              ? Colors.green
                              : Colors.red,
                        ),
                        title: Text(transaction['type'] == 'income'
                            ? 'Pemasukan'
                            : 'Pengeluaran'),
                        subtitle: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                                'Tanggal: ${_formatDate(transaction['date'])}'),
                            Text('Deskripsi: ${transaction['description']}'),
                          ],
                        ),
                        trailing: Text(
                          'Rp ${_formatCurrency(transaction['amount'])}',
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: transaction['type'] == 'income'
                                ? Colors.green
                                : Colors.red,
                          ),
                        ),
                      ),
                    );
                  },
                ),
    );
  }

  // Fungsi untuk format angka sebagai mata uang
  String _formatCurrency(double amount) {
    final format = NumberFormat('#,###', 'id_ID');
    return format.format(amount);
  }
}
