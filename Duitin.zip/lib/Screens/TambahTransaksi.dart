import 'package:flutter/material.dart';
import 'package:dio/dio.dart';

class TambahTransaksi extends StatefulWidget {
  final String? iduser;

  TambahTransaksi({Key? key, this.iduser}) : super(key: key);

  @override
  _TambahTransaksiState createState() => _TambahTransaksiState();
}

class _TambahTransaksiState extends State<TambahTransaksi> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _amountController = TextEditingController();
  final TextEditingController _descriptionController = TextEditingController();
  String _type = 'income'; // Default type

  Dio dio = Dio();

  Future<void> tambahTransaksi() async {
    if (_formKey.currentState!.validate()) {
      try {
        final response = await dio.post(
          'http://[::1]/vigenesia/api/Post_Transaksi',
          data: {
            'iduser': widget.iduser,
            'type': _type,
            'amount': _amountController.text,
            'description': _descriptionController.text,
          },
        );

        if (response.statusCode == 200 && response.data['status']) {
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            content: Text('Transaksi berhasil ditambahkan!'),
          ));
          Navigator.pop(context, true); // Kembali ke halaman sebelumnya
        } else {
          throw Exception(response.data['message']);
        }
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('Gagal menambahkan transaksi: $e'),
        ));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Tambah Transaksi'),
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              DropdownButtonFormField<String>(
                value: _type,
                items: [
                  DropdownMenuItem(value: 'income', child: Text('Pemasukan')),
                  DropdownMenuItem(value: 'expense', child: Text('Pengeluaran')),
                ],
                onChanged: (value) {
                  setState(() {
                    _type = value!;
                  });
                },
                decoration: InputDecoration(
                  labelText: 'Jenis Transaksi',
                  border: OutlineInputBorder(),
                ),
              ),
              SizedBox(height: 16),
              TextFormField(
                controller: _amountController,
                keyboardType: TextInputType.number,
                decoration: InputDecoration(
                  labelText: 'Jumlah',
                  border: OutlineInputBorder(),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Jumlah harus diisi';
                  }
                  return null;
                },
              ),
              SizedBox(height: 16),
              TextFormField(
                controller: _descriptionController,
                decoration: InputDecoration(
                  labelText: 'Deskripsi',
                  border: OutlineInputBorder(),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Deskripsi harus diisi';
                  }
                  return null;
                },
              ),
              SizedBox(height: 24),
              ElevatedButton(
                onPressed: 
                tambahTransaksi,
                child: Text('Tambah Transaksi'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
