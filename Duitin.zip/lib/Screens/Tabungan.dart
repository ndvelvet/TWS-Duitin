import 'package:flutter/material.dart';
import 'package:vigenesia/Screens/Beranda.dart';
import 'package:vigenesia/Screens/Login.dart';
import 'package:vigenesia/Screens/MainScreens.dart';
import 'package:vigenesia/Models/Tabungan_model.dart';
import 'package:dio/dio.dart';
import 'dart:convert';
import 'package:intl/intl.dart';
import 'package:vigenesia/Screens/Riwayat_Transaksi.dart';
import 'package:vigenesia/Screens/TambahTransaksi.dart';
import 'package:vigenesia/Screens/Target_Tabungan.dart';

class Tabungan extends StatefulWidget {
  final String? nama;
  final String? iduser;
  const Tabungan({Key? key, this.nama, this.iduser}) : super(key: key);

  @override
  State<Tabungan> createState() => _TabunganState();
}

class _TabunganState extends State<Tabungan> {
  double currentBalance = 0.0;
  double totalIncome = 0.0;
  double totalExpense = 0.0;
  bool isLoading = true;

  Dio dio = Dio();

  @override
  void initState() {
    super.initState();
    fetchTabunganData();
  }

  // Fungsi untuk mengambil data dari API backend menggunakan Dio
  Future<void> fetchTabunganData() async {
    try {
      final response = await dio.get(
          'http://[::1]/vigenesia/api/Get_tabungan?iduser=${widget.iduser}');

      // Print response to check the structure
      print('Response Data: ${response.data}');

      if (response.statusCode == 200) {
        var data = response.data['data'];

        if (data != null) {
          // Use the _parseCurrency function to remove commas and parse the values
          double currentBalance = _parseCurrency(data['currentbalance']);
          double totalIncome = _parseCurrency(data['totalincome']);
          double totalExpense = _parseCurrency(data['totalexpense']);

          // Set the values in the state
          setState(() {
            this.currentBalance = currentBalance;
            this.totalIncome = totalIncome;
            this.totalExpense = totalExpense;
            isLoading = false;
          });
        } else {
          throw Exception('No data available');
        }
      } else {
        throw Exception('Failed to load data');
      }
    } catch (e) {
      print('Error fetching data: $e');
      setState(() {
        isLoading = false;
      });
    }
  }

  // Helper function to parse currency formatted strings
  double _parseCurrency(String value) {
    // Remove commas and try to parse the value
    value = value.replaceAll(',', '');
    return double.tryParse(value) ?? 0.0;
  }

  String _formatNumber(double value) {
    final format =
        NumberFormat('#,###', 'id_ID'); // Format dengan pemisah ribuan
    return format.format(value);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Tabungan"),
        leading: Builder(
          builder: (BuildContext context) {
            return IconButton(
              icon: Icon(Icons.menu),
              onPressed: () {
                Scaffold.of(context).openDrawer(); // Membuka Drawer saat diklik
              },
            );
          },
        ),
        actions: [
          // Tambahkan tombol untuk Riwayat Transaksi di kanan atas
          IconButton(
            icon: Icon(Icons.history),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => RiwayatTransaksi(
                        iduser: widget
                            .iduser)), // Pastikan Anda sudah membuat halaman RiwayatTransaksi
              );
            },
          ),
        ],
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: <Widget>[
            DrawerHeader(
              decoration: BoxDecoration(
                color: Colors.blue,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  CircleAvatar(
                    radius: 30,
                    backgroundColor: Colors.white,
                    child: Icon(
                      Icons.person,
                      size: 40,
                      color: Colors.blue,
                    ),
                  ),
                  SizedBox(height: 10),
                  Text(
                    'Halo, ${widget.nama ?? 'Pengguna'}',
                    style: TextStyle(color: Colors.white, fontSize: 16),
                  ),
                  Text(
                    widget.iduser ?? '',
                    style: TextStyle(color: Colors.white70, fontSize: 14),
                  ),
                ],
              ),
            ),
            ListTile(
              leading: Icon(Icons.home),
              title: Text('Beranda'),
              onTap: () {
                Navigator.pop(context);
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => Beranda(
                              nama: widget.nama,
                              iduser: widget.iduser,
                            )));
              },
            ),
            ListTile(
              leading: Icon(Icons.star),
              title: Text('Motivasi'),
              onTap: () {
                Navigator.pop(context);
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => MainScreens(
                              nama: widget.nama,
                              iduser: widget.iduser,
                            )));
              },
            ),
            ListTile(
              leading: Icon(Icons.account_balance_wallet),
              title: Text('Tabungan'),
              onTap: () {
                Navigator.pop(context);
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => Tabungan(
                              nama: widget.nama,
                              iduser: widget.iduser,
                            )));
              },
            ),
            ListTile(
              leading: Icon(Icons.track_changes),
              title: Text('Target Tabungan'),
              onTap: () {
                Navigator.pop(context);
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => TargetTabungan(
                              nama: widget.nama,
                              iduser: widget.iduser,
                            )));
              },
            ),
            ListTile(
              leading: Icon(Icons.logout),
              title: Text('Keluar'),
              onTap: () {
                Navigator.pop(context); // Tutup Drawer
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => Login()),
                );
              },
            ),
          ],
        ),
      ),
      body: isLoading
          ? Center(child: CircularProgressIndicator())
          : Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Saldo Saat Ini
                  Card(
                    color: Colors.teal[50],
                    child: ListTile(
                      leading: Icon(Icons.account_balance_wallet,
                          color: Colors.teal),
                      title: Text(
                        'Saldo Saat Ini',
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      subtitle: Text(
                        // 'Rp ${currentBalance.toStringAsFixed(0)}',
                        'Rp ${_formatNumber(currentBalance)}',
                        style: TextStyle(fontSize: 18, color: Colors.teal[900]),
                      ),
                    ),
                  ),
                  SizedBox(height: 16),
                  // Total Pemasukan
                  Card(
                    color: Colors.green[50],
                    child: ListTile(
                      leading: Icon(Icons.arrow_downward, color: Colors.green),
                      title: Text(
                        'Total Pemasukan',
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      subtitle: Text(
                        // 'Rp ${totalIncome.toStringAsFixed(0)}',
                        'Rp ${_formatNumber(totalIncome)}',
                        style:
                            TextStyle(fontSize: 18, color: Colors.green[900]),
                      ),
                    ),
                  ),
                  SizedBox(height: 16),
                  // Total Pengeluaran
                  Card(
                    color: Colors.red[50],
                    child: ListTile(
                      leading: Icon(Icons.arrow_upward, color: Colors.red),
                      title: Text(
                        'Total Pengeluaran',
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      subtitle: Text(
                        // 'Rp ${totalExpense.toStringAsFixed(0)}',
                        'Rp ${_formatNumber(totalExpense)}',
                        style: TextStyle(fontSize: 18, color: Colors.red[900]),
                      ),
                    ),
                  ),
                  SizedBox(height: 32),
                  // Tombol untuk Tambah Transaksi
                  Center(
                    child: ElevatedButton(
                      onPressed: () async {
                        // Navigasi ke halaman Tambah Transaksi
                        final result = await Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) =>
                                  TambahTransaksi(iduser: widget.iduser)),
                        );

                        // Jika transaksi berhasil ditambahkan, refresh data
                        if (result == true) {
                          fetchTabunganData();
                        }
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.teal,
                        padding:
                            EdgeInsets.symmetric(horizontal: 50, vertical: 15),
                      ),
                      child: Text(
                        'Tambah Transaksi',
                        style: TextStyle(fontSize: 16, color: Colors.white),
                      ),
                    ),
                  ),
                ],
              ),
            ),
    );
  }
}
