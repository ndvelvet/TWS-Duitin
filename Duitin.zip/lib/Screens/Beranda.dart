import 'package:flutter/material.dart';
import 'package:vigenesia/Screens/Login.dart';
import 'package:vigenesia/Screens/MainScreens.dart';
import 'package:vigenesia/Screens/Tabungan.dart';
import 'package:vigenesia/Screens/Target_Tabungan.dart';

class Beranda extends StatelessWidget {
  final String? nama;
  final String? iduser;

  const Beranda({Key? key, this.nama, this.iduser}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Beranda"),
        leading: Builder(
          builder: (BuildContext context) {
            return IconButton(
              icon: Icon(Icons.menu),
              onPressed: () {
                Scaffold.of(context).openDrawer(); // Membuka Drawer saat diklik
              },
            );
          },
        ),
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: <Widget>[
            DrawerHeader(
              decoration: BoxDecoration(
                color: Colors.blue,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  CircleAvatar(
                    radius: 30,
                    backgroundColor: Colors.white,
                    child: Icon(
                      Icons.person,
                      size: 40,
                      color: Colors.blue,
                    ),
                  ),
                  SizedBox(height: 10),
                  Text(
                    'Halo, ${nama ?? 'Pengguna'}',
                    style: TextStyle(color: Colors.white, fontSize: 16),
                  ),
                  Text(
                    iduser ?? '',
                    style: TextStyle(color: Colors.white70, fontSize: 14),
                  ),
                ],
              ),
            ),
            ListTile(
              leading: Icon(Icons.home),
              title: Text('Beranda'),
              onTap: () {
                Navigator.pop(context); // Tutup Drawer
                // Navigasi ke halaman utama
              },
            ),
            ListTile(
              leading: Icon(Icons.star),
              title: Text('Motivasi'),
              onTap: () {
                Navigator.pop(context);
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => MainScreens(
                              nama: nama,
                              iduser: iduser,
                            ))); // Tutup Drawer
                // Navigasi ke halaman profil
              },
            ),
            ListTile(
              leading: Icon(Icons.account_balance_wallet),
              title: Text('Tabungan'),
              onTap: () {
                Navigator.pop(context);
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => Tabungan(
                              nama: nama,
                              iduser: iduser,
                            )));
              },
            ),
            ListTile(
              leading: Icon(Icons.track_changes),
              title: Text('Target Tabungan'),
              onTap: () {
                Navigator.pop(context);
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => TargetTabungan(
                            //nama: widget.nama,
                            //iduser: widget.iduser,
                            )));
              },
            ),
            ListTile(
              leading: Icon(Icons.logout),
              title: Text('Keluar'),
              onTap: () {
                Navigator.pop(context); // Tutup Drawer
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => Login()),
                );
              },
            ),
          ],
        ),
      ),
      body: Center(
        child: Text('Selamat Datang, ${nama ?? 'Pengguna'} di Duitin'),
      ),
    );
  }
}
